function regist_fail(){
    alert("사용자 등록에 실패하셨습니다.\n 잘못된 시리얼 넘버거나 이미 등록된 유저입니다.");
    window.close();
}