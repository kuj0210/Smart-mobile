
dic = {}
dic['hi']="hell"
dic['my']="me"

for i in dic:
    print(i)