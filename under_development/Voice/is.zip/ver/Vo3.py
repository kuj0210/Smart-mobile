from observer import *
import wave
import numpy as np
from numpy.lib import stride_tricks
import pylab
import pyaudio
import prediction_simulation

#녹화와 채널수 및 파일 설정.
class Vo(Observer):
    FORMAT = pyaudio.paInt16
    CHANNELS = 1
    RATE = 44100
    CHUNK = 512
    RECORD_SECONDS = 5
    DEVICE_INDEX = -1
    WAVE_OUTPUT_FILENAME = "file.wav"
    Recode_Value = 1000

    def __init__(self,Push):
        self.reSet(Push)


        po = pyaudio.PyAudio()
        for index in range(po.get_device_count()):
            desc = po.get_device_info_by_index(index)
            if desc["name"] == "USB Audio Device":
                self.DEVICE_INDEX = index
                break