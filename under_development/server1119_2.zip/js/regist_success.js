function regist_success(){
    alert("사용자 등록에 성공하셨습니다.\n 환영합니다!");
    window.close();
}