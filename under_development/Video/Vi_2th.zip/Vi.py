from observer import *
import cv2
import numpy as np
import os

class Vi(Observer):
    NAME = 'VI'
    PUSHCODE_P1 = NAME+"-사진"
    PICTURE_NAME = ""

    cap = 0
    frame = []
    picture = []

    def __init__(self,Push):
        self.EV_PUSH = Vi.NAME+"관측 푸쉬"
        self.RQ_PUSH = Vi.NAME+"요청처리 메세지"
        self.reSet(Push)
        self.mPush = Push
        self.setImagePusher()
        self.dPusher = self.mPush.insertMSG
        os.system('sudo modprobe bcm2835-v4l2')

    def processRequest(self, PUSHCODE):
        try:
            if (PUSHCODE == self.PUSHCODE_P1):
                print("Vi - picture request")
                self.writePicture()
                return self.PICTURE_NAME
            else:
                return False
        except:
            print("Vi - request 에러")
            return False

    def openCamera(self):
        self.cap = cv2.VideoCapture(0)
        if self.cap is None:
            print("openCamera 에러")
            return
        ret, self.frame = self.cap.read()
        self.cap.release()

    def writePicture(self):
        if os.path.isfile("./" + self.PICTURE_NAME):
            os.remove("./" + self.PICTURE_NAME)
        now = datetime.now()
        self.PICTURE_NAME = self.mPush.T.SERIAL + '_%s-%s-%s-%s-%s-%s' %(now.year, now.month, now.day, now.hour, now.minute, now.second) + ".png"
        cv2.imwrite(self.PICTURE_NAME, self.frame)


if __name__ == "__main__":
    vi=Vi(Observer)
    vi.run()
