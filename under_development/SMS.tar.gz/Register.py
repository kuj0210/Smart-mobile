import pymysql
from DBString import *
from defaultMessage import*
class Register:
	def __init__(self):
		self.mMsgList=MessageList()
		# DB 계정정보 관리
		self.conn = None
		self.curs = None
		self.serial = None
		self.host = "localhost"
		self.user = "root"
		self.pw = "1234"
		self.charset = "utf8"

		#로그 정보
		self.LOG = "DB_LOG"
		#전달 문자
		self.SQL =  DBString()
		

		
      
	def connectDB(self):
		self.conn = pymysql.connect(host=self.host, user=self.user, password=self.pw, charset=self.charset)
		self.curs = self.conn.cursor()

	def checkUserTable(self):
		try:
		    with self.conn.cursor() as self.curs:        
		    	self.curs.execute(self.SQL.US_DBQ)
		except:
		    with self.conn.cursor() as self.curs:
		        self.curs.execute(self.SQL.CT_DBQ )
		    self.conn.commit()

		    with self.conn.cursor() as self.curs:
		        self.curs.execute(self.SQL.US_DBQ)

		   
		    try:
		        with self.conn.cursor() as self.curs:
		            self.curs.execute(self.SQL.ST_UTQ)
		    except:
		        with self.conn.cursor() as self.curs:
		            self.curs.execute(self.SQL.CT_UTQ)
		    self.conn.commit()

	def checkSystemTable(self):
		try:
			with self.conn.cursor() as self.curs:
				self.curs.execute(self.SQL.ST_STQ)
		except:
			with self.conn.cursor() as self.curs:
				self.curs.execute(self.SQL.CT_STQ)
		self.conn.commit()

	def openDB(self):
		self.connectDB()
		self.checkUserTable()
		self.checkSystemTable()


	def closeDB(self):
		self.conn.close()

	def checkRegistedUserForOuter(self, user_key):
		self.openDB()
		try:
			with self.conn.cursor() as self.curs:
				query = self.SQL.getQ_ST_U_FromUserKey(user_key)
				self.curs.execute(query)
				rows = self.curs.fetchall()
				self.closeDB()
				if len(rows) > 0: 
					return True
				else:
					return False
		except:
				self.closeDB()
				return False
		self.closeDB()
			

	def checkRegistedUser(self, user_key):
		try:
			with self.conn.cursor() as self.curs:
				query = self.SQL.getQ_ST_U_FromUserKey(user_key)
				self.curs.execute(query)
				rows = self.curs.fetchall()
				if len(rows) > 0: 
					return True
				else:
					return False
		except:
				return False
		

	def checkRegistedSerial(self, serial):
		try:
			with self.conn.cursor() as self.curs:
				query = self.SQL.getQ_ST_S_FromSerial(serial)
				self.curs.execute(query)
				rows = self.curs.fetchall()
				if len(rows) > 0: 
					return True
				else :
					return False

		except:
				return False

			


	def insertUserData(self, user_key, serial):
		self.openDB()
		with self.conn.cursor() as self.curs:
			if self.checkRegistedUser(user_key) == True:
				return self.mMsgList.ERR_REGISTERD_USER
			try:
				if self.checkRegistedSerial(serial) == False:
					return self.mMsgList.ERR_NO_REGISTERD_SERIA
				
				with self.conn.cursor() as self.curs:
					self.curs.execute(self.SQL.getQ_IT_U(user_key,serial))
					self.conn.commit()
				self.closeDB()
				return self.mMsgList.SUCESS_IST_USER
			except:
				self.closeDB()
				return self.mMsgList.ERR_REGISTE_USER
		self.closeDB()



	
	def deleteUserData(self, user_key):
		self.openDB()
		with self.conn.cursor() as self.curs:
			if self.checkRegistedUser(user_key) == False:
				return self.mMsgList.SUCESS_DEL_NO_REGISTERD_USER
			try:
				with self.conn.cursor() as self.curs:
					self.curs.execute(self.SQL.getQ_DT_U(user_key))
					self.conn.commit()
				self.closeDB()
				return self.mMsgList.SUCESS_DEL_REGISTERD_USER
			except:
				self.closeDB()
				return  self.mMsgList.ERR_DEL_REGISTERD_USER
		self.closeDB()	

	def getURL(self,UK):
		self.openDB()
		try:
			print("1번 트라이")
			with self.conn.cursor() as self.curs:
				print("2번 위드")
				self.curs.execute(self.SQL.getQ_ST_S_FromUser(UK)) 
				SR =self.curs.fetchall()[0][0]
				print("SR")
				self.curs.execute(self.SQL.getQ_ST_URL_fromSerial(SR))
				URL =self.curs.fetchall()[0][0]
				print("URL")
			self.closeDB()
			return URL
		except:
			self.closeDB()
			return  self.mMsgList.ERR_SCH_URL
		self.closeDB()	

if __name__ == "__main__":
	user ="u9-NF6yuZ8H8TAgj1uzqnQ"
	Reg =Register(MessageList())
	print(Reg.SQL.getQ_ST_S_FromUser(user))
	print(Reg.getURL(user))
	