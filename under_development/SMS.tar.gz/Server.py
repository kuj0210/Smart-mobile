#-*-coding: utf-8-*-
from flask import Flask,request,jsonify,send_from_directory
from serverManageMent import NaverManager 
import compareSentence
from konlpy.corpus import kolaw
import jpype
from Register import *

THusecaseFinder =compareSentence.UsecaseFinder()
UPLOAD_FOLDER = 'uploaded'

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER



@app.route("/",methods=["POST"])
def naver_Servermain():
    # make manager
    Manager =NaverManager()
    # get data from naver  talk talk
    dataFromMessenger =request.get_json()# get json data from naver talk talk
    infomationFromNaverTalk=Manager.getDataFromNaverTalk(dataFromMessenger) # it is process for data sorting
    user =infomationFromNaverTalk["user"]
    postBodyMessage = Manager.eventHandler(infomationFromNaverTalk) # process event
    if postBodyMessage == "ECHO":
      return
    return jsonify(postBodyMessage), 200

@app.route("/bootUp",methods=["POST"])
def bootUpMobile():
    # make manager
    reg = Register()
    dataFromMessenger =request.get_json()# get json data from naver talk talk
    SR=dataFromMessenger['textContent']['text']
    reg.openDB()
    UK=reg.getUserFromSerial(SR)
    reg.closeDB()
    return UK 

@app.route("/RQST",methods=["POST"])
def passRequest():
    reg = Register()
    dataFromMessenger =request.get_json()# get json data from naver talk talk
    SR=dataFromMessenger['textContent']['text']
    rq=reg.fetchRequest(SR)
    if rq == False:
        return "NO"
    return rq
 
@app.route("/push",methods=["POST"])
def pushResult():
    nM=NaverManager()
    dataFromMessenger =request.get_json()# get json data from naver talk talk
    user =msg=dataFromMessenger['user']
    msg=dataFromMessenger['textContent']['text']
    nM.sendPush(nM.PUSH_URL,user,msg)
    
    return "True"






if __name__ == "__main__":
    ssl_cert = '/etc/letsencrypt/live/www.kit-iot-system.tk/fullchain.pem'
    ssl_key =  '/etc/letsencrypt/live/www.kit-iot-system.tk/privkey.pem'
    contextSSL =  (ssl_cert, ssl_key)
    #user ="u9-NF6yuZ8H8TAgj1uzqnQ"
    app.run(host='0.0.0.0', port=443, debug = True, ssl_context = contextSSL)
