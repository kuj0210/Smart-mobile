from apscheduler.jobstores.base import JobLookupError
from apscheduler.schedulers.background import BackgroundScheduler
import time
from serverManageMent import NaverManager 
from Register import Register
class Scheduler(object):

    # 클래스 생성시 스케쥴러 데몬을 생성합니다.
    def __init__(self,id,h,m,s):
        self.sched = BackgroundScheduler()
        self.sched.start()
        self.job_id=id
        self.rg =Register()

        self.TM_H = h
        self.TM_M = m
        self.TM_S = s
      
        self.index = 0
        
        print("thread")


    # 클래스가 종료될때, 모든 job들을 종료시켜줍니다.
    def __del__(self):
        self.shutdown()

    # 모든 job들을 종료시켜주는 함수입니다.
    def shutdown(self):
        self.sched.shutdown()

    # 특정 job을 종료시켜줍니다.
    def kill_scheduler(self):
        try:
            self.sched.remove_job(self.job_id)
        except JobLookupError as err:
            print( "fail to stop scheduler: %s" % err)
           

    def serverAlam(self, type,job_id):
        print("wake up")
        nM = NaverManager()
        tm = time.localtime()
      
        userList =self.rg.getALL_UserKey()
        Len = self.rg.getMsgTableLen()
        self.index%=Len
        self.index+=1
        msg =self.rg.getMSGfromIDX(self.index )
        print("test1")
        print(msg)
        print(index)
        print(userList)
        for user in userList:
            print("in loop")
            nM.sendPush(nM.PUSH_URL,user,"오늘의 꿀팁")
            nM.sendIMAG(user, nM.IMAGE_URL +msg)
          

    #day_of_week = 0~7 의값 or 요일앞3자리
    #hour = 0~23 중하나 또는 '0-23' 등 기간도 가능
    #min = 0~59 또는 '0-23' 등 기간도 가능
    #sec = 0~59 또는 '0-23' 등 기간도 가능
    def scheduler(self):
        print("sche on")
        self.sched.add_job(self.serverAlam, 'cron', day_of_week='mon-fri',hour=self.TM_H,minute=self.TM_M, second=self.TM_S,id=self.job_id, args=('cron', self.job_id))
        print("sche off")

   
            


if __name__ == '__main__':
    scheduler1 = Scheduler(id='1',h='0-23',m='0-59',s='0-59')
 

    # cron 스케쥴러를 실행시키며, job_id는 "1" 입니다.

   

    count = 0
    while True:
        print ("wait")
        time.sleep(10)
        count += 1

