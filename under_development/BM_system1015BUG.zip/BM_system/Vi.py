from observer import *
import cv2
import numpy as np
import time
import os

class Vi(Observer):
    frame = []
    cap = 0

    def __init__(self,Push):
        self.reSet(Push)
        self.mPush = Push

    def sendPicture(self):
        self.cap = cv2.VideoCapture(0)
        if self.old_frame is None:
            print("camera error1")
            return
        ret, self.frame = self.cap.read()
        cv2.imshow('Picture', self.frame)

    def run(self):
        print("Running Vi")
        os.system('sudo modprobe bcm2835-v4l2')
        while(True):
            try :
                item = self.popRQ()
            except :
                print("Vo에서 popRQ 리퀘스트 받기 에러")
                continue
            if (item != False):
                try :
                    print("Running picture request")
                    sendPIcture()
                    cv2.imwrite(self.mPush.T.SERIAL + ".png" , self.frame)
                    self.mPush.T.pushImage(item.user,self.mPush.T.SERIAL + ".png" )
                    self.cap.release()
                except :
                    print('Picture push error')
                    continue
        cv2.destroyAllWindows()
        time.sleep(15)


if __name__ == "__main__":
    vi=Vi(Observer)
    vi.run()
