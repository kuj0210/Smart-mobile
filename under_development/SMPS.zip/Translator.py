import requests
import json

class Translator():
    userList = []
    def __init__(self):
        # URL 관리
        self.SERVER_URL = "https://www.kit-iot-system.tk:443/"
        self.PUSH_URL = self.SERVER_URL+"push"
        self.BOOT_URL = self.SERVER_URL + "bootUp"
        self.RQST_URL = self.SERVER_URL + "RQST"
        #헤더
        self.Send_Header = {"Content-Type": "application/json;charset=UTF-8", "Authorization": "MOBILE _YSTEM"}
    def getPostBodyMessage(self,user,text):
        postBodyMessage = {
            "event": "send",
            "user" : user,
            "textContent": {
                "text": text
            },
            "options": {
                "notification": "true"
            }
        }
        return postBodyMessage
    def sendMsg(self,url,user,msg):
        res = requests.post(url=url, headers=self.Send_Header, data=json.dumps(self.getPostBodyMessage(user,msg)))
        return str(res.__dict__['_content'], encoding='utf-8')
    def pushToUser(self,user,msg):
        self.sendMsg(self.PUSH_URL,user,msg)
    def pushToAllUser(self,msg):
        for user in self.userList:
            self.pushToUser(user,msg)