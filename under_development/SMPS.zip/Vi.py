from observer import *
import time

class Vi(Observer):
    def __init__(self,Push):
        Observer.__init__(Observer,Push)


    def run(self):
        while(True):
            # 사진요청이 왓다면 사진파일 만드는 일까지, 만들기만 할것 전송은 나중에 짤예정
            item = self.popRQ()
            if (item != False):
                self.mPush.insertMSG(item.user,item.msg)


            ##여기서부터는 평소처럼 관측
            if(True): #이탈 시

                time.sleep(5)
                self.mPush.insertMSG('ALL',"PUSH :vi 스레드")



