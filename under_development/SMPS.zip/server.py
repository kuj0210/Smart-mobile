import requests
import json
import time

class Translator():
    def __init__(self):
        # URL 관리
        self.SERVER_URL = "https://www.kit-iot-system.tk:443/"
        self.PUSH_URL = self.SERVER_URL+"push"
        self.BOOT_URL = self.SERVER_URL + "bootUp"
        self.RQST_URL = self.SERVER_URL + "RQST"
        #헤더
        self.Send_Header = {"Content-Type": "application/json;charset=UTF-8", "Authorization": "MOBILE _YSTEM"}
    def getPostBodyMessage(self,user,text):
        postBodyMessage = {
            "event": "send",
            "user" : user,
            "textContent": {
                "text": text
            },
            "options": {
                "notification": "true"
            }
        }
        return postBodyMessage
    def sendMsg(self,url,user,msg):
        res = requests.post(url=url, headers=self.Send_Header, data=json.dumps(self.getPostBodyMessage(user,msg)))
        return str(res.__dict__['_content'], encoding='utf-8')

class MobileSystem:
    def __init__(self):
        self.T = Translator()
        self.CONFIG = "configPI.txt"
        #시스템 정보
        self.SERIAL=""
        self.userList=[]
        #값 초기화
        if self.loadSerail() ==False:
            exit()
        self.bootUp()
        print("프로그램 안전부팅 완료")
    def parshResponseByNL(self,res):
        res =res.split("\n")
        res.pop()
        for i in range(len(res)):
            res[i]=res[i].strip()
        return res
    def parshResponseBySP(self,res):
        res =res.split(" ")
        return res


    def loadSerail(self):
        try:
            with open(self.CONFIG, "r") as f:
                self.SERIAL=f.readline()
                return True
        except:
            print("파일 입출력 에러")
            return False
        return False
    def bootUp(self):
        res=self.T.sendMsg(self.T.BOOT_URL,"NO_USER",self.SERIAL)
        self.userList= self.parshResponseByNL(res)
    def pushToUser(self,user,msg):
        self.T.sendMsg(self.T.PUSH_URL,user,msg)
    def pushToAllUser(self,msg):
        for user in self.userList:
            self.pushToUser(user,msg)
    def getRequest(self,wating):
        time.sleep(wating)
        res = self.T.sendMsg(self.T.RQST_URL,"NO_USER",self.SERIAL)
        if 'NO' in res:
            return False
        res =self.parshResponseByNL(res)
        list =[]
        for item in res:
            atom = self.parshResponseBySP(item)
            atom.pop(0)
            list.append(atom)
        return list
    def runMobile(self):
        print("프로그램 시작합니다.")
        while True:
            list =self.getRequest(1)
            if list ==False:
                continue
            else:
                list =list.pop(0)
                user = list.pop(0)
                str ="모빌 시스템에서 응신합니다!.id: %s 님의 "%user
                str+=" ".join(list) +"기능이 수행 완료되었습니다"
                print(str)
                self.pushToUser(user,str)


if __name__ =="__main__":
    MS=MobileSystem()
    MS.runMobile()

