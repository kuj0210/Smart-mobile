from observer import *

class Info(Observer):
    # 사용자의 요청 구분 예)목소리들려줘 노래들려줘 구분, 외부 참조내용 내부에서 구분할때도 사용할것
    NAME = 'VI'
    PUSHCODE_P1 = NAME+"-ob1"
    PUSHCODE_P2 = NAME+"-ob2"
    PUSHCODE_P3 = NAME+"-ob3"

    def __init__(self,Push):
        self.EV_PUSH = Info.NAME+"관측 푸쉬"
        self.RQ_PUSH = Info.NAME+"요청처리 메세지"
        self.reSet(Push)
        self.mPush = Push

    #오버라이딩, 요청처리기능 만약 하위 클래스가 처리하는게 없다면 False 반환
    def processRequest(self, PUSHCODE):
        if (PUSHCODE !=-1): #넘어오는 코드별로 분류하여 행동처리 PUSHCODE == PUSHCODE_P1 이런식으로
            return self.RQ_PUSH +"  "+PUSHCODE
        else:
            return False

    # 오버라이딩, 관측 중 푸쉬해야하는 상황이 발생하면 정의해둔 메세지 리턴
    def detectEnvironment(self):
        res = False  # 적당한 메서드를 호출해서 알람발생해야한다면 알람에 들어갈 메세지 리턴하게할것
        # 반드시 위에 상수를 참조하여 쓸 걸

        if (res == False):
            return False
        else:  # 필요시 elif등 사용할것
            return self.res

