function checkRegist(){
    if(confirm("사용자 등록을 하시겠습니까?")){
        return true;
    } else {
        return false;
    }
}